package com.store.greenShoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenShoeStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
