package com.store.greenShoes.DTO;

public class LoginDTO {
	private String userName;
	private String userPassword;
	
}
