import NavBar from "@/components/NavBar";
import LeftMenu from "@/components/leftMenu";

const HelloWorld = () => {
  return (
   <LeftMenu/>
  );
}

export default HelloWorld;

